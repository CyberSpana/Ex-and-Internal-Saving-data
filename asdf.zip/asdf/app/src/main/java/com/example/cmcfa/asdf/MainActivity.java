package com.example.cmcfa.asdf;

import android.Manifest;
import android.app.usage.ExternalStorageStats;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.Console;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.String;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    //text
    EditText et_text;

    Button b_writer, b_reader;

    TextView tv_text;

    //file name
    String fileName = "file.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_text = (EditText) findViewById(R.id.et_text);

        b_writer = (Button) findViewById(R.id.b_writer);

        b_reader = (Button) findViewById(R.id.b_reader);

        tv_text = (TextView) findViewById(R.id.tv_text);

        b_reader.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                tv_text.setText(readFile(fileName));
            }
        });

        b_writer.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                saveFile(fileName, et_text.getText().toString());
            }
        });

    }

    private boolean isExternalStorageWritable(){
        if(Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())){
            Log.i("State", "Yes, it is writable");
            return true;
        }else{
            return false;
        }
    }

    public void saveFile(String file, String text){
        try{
            FileOutputStream fos = openFileOutput(file, Context.MODE_PRIVATE);
            fos.write(text.getBytes());
            fos.close();
            Toast.makeText(MainActivity.this, "Saved!", Toast.LENGTH_SHORT).show();
        }catch(Exception e){
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Error Saving File", Toast.LENGTH_SHORT).show();
        }

    }

    public String readFile(String file){
        String text = "";
        try{
            FileInputStream fis = openFileInput(file);
            int size = fis.available();
            byte[] buffer = new byte[size];
            fis.read(buffer);
            fis.close();
            text = new String(buffer);
        }catch(Exception e){
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Error Reading File", Toast.LENGTH_LONG).show();
        }
        return text;
    }

    public void writeFile(View v){
        if(isExternalStorageWritable() && checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)){
        File textFile = new File(Environment.getExternalStorageDirectory(), fileName);

        try{
            FileOutputStream fos = new FileOutputStream(textFile);
            fos.write(et_text.getText().toString().getBytes());
            fos.close();

            Toast.makeText(this, "File Saved To External Storage", Toast.LENGTH_SHORT).show();
        }catch(IOException e){
            e.printStackTrace();
        }
    }else{
            Toast.makeText(this, "Cannot Write To External Storage", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean checkPermission(String permission){
        int check = ContextCompat.checkSelfPermission(this, permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}
